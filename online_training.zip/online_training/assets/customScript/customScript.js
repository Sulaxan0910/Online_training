
function saveUser(type, id, postUrl) {
  var userName;
  var fullName;
  var email;
  var userType;
  var userDepartment;
  var password;
    if (type) {
        userName = $('#editUsername').val();
        fullName = $('#editFullName').val();
        email = $('#editEmail').val();
        userType = $('#editUserType').val();
        password = $('#editPassword').val();
        var id = $('#editId').val();
        var type = 1;

        if (userName == null || userName == "" || fullName == null || fullName == "" || email == null || userType == null || userType == "" || userDepartment == null || userDepartment == "" || (!validateEmail(email))) {
            $("#displayDiv").empty();
            $("#displayDiv").prepend("<div class='alert alert-danger alert-dismissable fade show' id='alertDiv'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button><p style='margin-bottom: 0rem !important;'><strong>Warning!</strong> Best check yo self, you're not looking too good. <a href='#' class='alert-link'>alert link</a></p></div>");
            $('#displayDiv').show();
        } else {
            $.ajax({
                type: 'POST',
                url: postUrl,
                data: { userName: userName, fullName: fullName, email: email, userType: userType, userDepartment: userDepartment, password: password, id: id }/*$('#editForm'+id).serialize()*/,
                dataType: 'JSON',
                success: function(response) {
                    if (response.flag == 0) {
                        $("#displayDiv").empty();
                        $("#displayDiv").prepend("<div class='alert alert-danger alert-dismissable fade show' id='alertDiv'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button><p style='margin-bottom: 0rem !important;'><strong>"+response.message+" </strong></p></div>");
                        $('#displayDiv').show();
                    } else {
                        $("#displayDiv").empty();
                        $("#displayDiv").prepend("<div class='alert alert-success alert-dismissable fade show' id='alertDiv'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button><p style='margin-bottom: 0rem !important;'><strong>"+response.message+" </strong></p></div>");
                        $('#displayDiv').show();
                    }

                    $('#editUsername').val("");
                    $('#editFullName').val("");
                    $('#editEmail').val("");
                    $('#editUserType').val("");
                    $('#editDepartment').val("");
                    $("#editUserModal").modal('hide')
                }
            });
        }
    } else {
        userName = $('#username').val();
        fullName = $('#fullName').val();
        email = $('#email').val();
        userType = $('#userType').val();
        password = $('#password').val();
        if (userName == null || userName == "" || fullName == null || fullName == "" || email == null || userType == null || userType == "" || userDepartment == null || userDepartment == "" || (!validateEmail(email)) || password == null || password == "") {
            $("#displayDiv").empty();
            $("#displayDiv").prepend("<div class='alert alert-danger alert-dismissable fade show' id='alertDiv'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button><p style='margin-bottom: 0rem !important;'><strong>Warning!</strong> Best check yo self, you're not looking too good. <a href='#' class='alert-link'>alert link</a></p></div>");
            $('#displayDiv').show();
        } else {
            $.ajax({
                type: 'POST',
                url: postUrl,
                data: { userName: userName, fullName: fullName, email: email, userType: userType, userDepartment: userDepartment, password: password, type: type }/*$('#newForm').serialize()*/,
                dataType: 'JSON',
                success: function(response) {
                    if (response.flag == 0) {
                        $("#displayDiv").empty();
                        $("#displayDiv").prepend("<div class='alert alert-danger alert-dismissable fade show' id='alertDiv'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button><p style='margin-bottom: 0rem !important;'><strong>"+response.message+" </strong></p></div>");
                        $('#displayDiv').show();

                    } else {
                        $("#displayDiv").empty();
                        $("#displayDiv").prepend("<div class='alert alert-success alert-dismissable fade show' id='alertDiv'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button><p style='margin-bottom: 0rem !important;'><strong>"+response.message+" </strong></p></div>");
                        $('#displayDiv').show();
                        $('#username').val("");
                        $('#fullName').val("");
                        $('#email').val("");
                        $('#userType').val("");
                        $('#department').val("");
                        $('#password').val("");
                        $("#addUserModal").modal('hide');
                    }
                }
            });
        }
    }
  }

  function saveTopic(type, postUrl) {
      var title;
      var course;
      var description;
      if (type) {
          title = $('#editTitle').val();
          course = $('#editCourse').val();
          description = $('#editDescription').val();
          var id = $('#editId').val();

          if (title == null || title == "" || course == null || course == "") {
              $("#displayDiv").empty();
              $("#displayDiv").prepend("<div class='alert alert-danger alert-dismissable fade show' id='alertDiv'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button><p style='margin-bottom: 0rem !important;'><strong>Warning!</strong> Best check yo self, you're not looking too good. <a href='#' class='alert-link'>alert link</a></p></div>");
              $('#displayDiv').show();
          } else {
              $.ajax({
                  type: 'POST',
                  url: postUrl,
                  data: { title: title, course: course, description: description, id: id },
                  dataType: 'JSON',
                  success: function(response) {
                      if (response.flag == 0) {
                          $("#displayDiv").empty();
                          $("#displayDiv").prepend("<div class='alert alert-danger alert-dismissable fade show' id='alertDiv'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button><p style='margin-bottom: 0rem !important;'><strong>"+response.message+" </strong></p></div>");
                          $('#displayDiv').show();
                      } else {
                          $("#displayDiv").empty();
                          $("#displayDiv").prepend("<div class='alert alert-success alert-dismissable fade show' id='alertDiv'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button><p style='margin-bottom: 0rem !important;'><strong>"+response.message+" </strong></p></div>");
                          $('#displayDiv').show();
                          $('#editTitle').val("");
                          $('#editCourse').val("");
                          $('#editDescription').val("");
                      }
                      $("#editTopicModal").modal('hide');
                      alert(response.message);
                      window.location.reload();
                  }
              });
          }
      } else {
          title = $('#title').val();
          course = $('#course').val();
          description = $('#description').val();
          if (title == null || title == "" || course == null || course == "") {
              $("#displayDiv").empty();
              $("#displayDiv").prepend("<div class='alert alert-danger alert-dismissable fade show' id='alertDiv'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button><p style='margin-bottom: 0rem !important;'><strong>Warning!</strong> Best check yo self, you're not looking too good. <a href='#' class='alert-link'>alert link</a></p></div>");
              $('#displayDiv').show();
          } else {
              $.ajax({
                  type: 'POST',
                  url: postUrl,
                  data: { title: title, course: course, description: description },
                  dataType: 'JSON',
                  success: function(response) {
                      if (response.flag == 0) {
                          $("#displayDiv").empty();
                          $("#displayDiv").prepend("<div class='alert alert-danger alert-dismissable fade show' id='alertDiv'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button><p style='margin-bottom: 0rem !important;'><strong>"+response.message+" </strong></p></div>");
                          $('#displayDiv').show();

                      } else {
                          $("#displayDiv").empty();
                          $("#displayDiv").prepend("<div class='alert alert-success alert-dismissable fade show' id='alertDiv'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button><p style='margin-bottom: 0rem !important;'><strong>"+response.message+" </strong></p></div>");
                          $('#displayDiv').show();
                          $('#title').val("");
                          $('#course').val("");
                          $('#description').val("");
                      }
                      alert(response.message);
                      window.location.reload();
                  }
              });
          }
      }
  }

  function saveCourse(type, postUrl) {
      var title;
      var description;
      var duration;
      if (type) {
          title = $('#editTitle').val();
          duration = $('#editDuration').val();
          description = $('#editDescription').val();
          var id = $('#editId').val();

          if (title == null || title == "" || duration == null || duration == "") {
              $("#displayDiv").empty();
              $("#displayDiv").prepend("<div class='alert alert-danger alert-dismissable fade show' id='alertDiv'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button><p style='margin-bottom: 0rem !important;'><strong>Warning!</strong> Best check yo self, you're not looking too good. <a href='#' class='alert-link'>alert link</a></p></div>");
              $('#displayDiv').show();
          } else {
              $.ajax({
                  type: 'POST',
                  url: postUrl,
                  data: { title: title, duration: duration, description: description, id: id },
                  dataType: 'JSON',
                  success: function(response) {
                      if (response.flag == 0) {
                          $("#displayDiv").empty();
                          $("#displayDiv").prepend("<div class='alert alert-danger alert-dismissable fade show' id='alertDiv'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button><p style='margin-bottom: 0rem !important;'><strong>"+response.message+" </strong></p></div>");
                          $('#displayDiv').show();
                      } else {
                          $("#displayDiv").empty();
                          $("#displayDiv").prepend("<div class='alert alert-success alert-dismissable fade show' id='alertDiv'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button><p style='margin-bottom: 0rem !important;'><strong>"+response.message+" </strong></p></div>");
                          $('#displayDiv').show();
                          $('#editTitle').val("");
                          $('#editDuration').val("");
                          $('#editDescription').val("");
                      }
                      alert(response.message);
                      window.location.reload();
                      $("#editTopicModal").modal('hide');
                  }
              });
          }
      } else {
          title = $('#title').val();
          duration = $('#duration').val();
          description = $('#description').val();

          if (title == null || title == "" || duration == null || duration == "") {
              $("#displayDiv").empty();
              $("#displayDiv").prepend("<div class='alert alert-danger alert-dismissable fade show' id='alertDiv'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button><p style='margin-bottom: 0rem !important;'><strong>Warning!</strong> Best check yo self, you're not looking too good. <a href='#' class='alert-link'>alert link</a></p></div>");
              $('#displayDiv').show();
          } else {
              $.ajax({
                  type: 'POST',
                  url: postUrl,
                  data: { title: title, duration: duration, description: description },
                  dataType: 'JSON',
                  success: function(response) {
                      if (response.flag == 0) {
                          $("#displayDiv").empty();
                          $("#displayDiv").prepend("<div class='alert alert-danger alert-dismissable fade show' id='alertDiv'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button><p style='margin-bottom: 0rem !important;'><strong>"+response.message+" </strong></p></div>");
                          $('#displayDiv').show();

                      } else {
                          $("#displayDiv").empty();
                          $("#displayDiv").prepend("<div class='alert alert-success alert-dismissable fade show' id='alertDiv'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button><p style='margin-bottom: 0rem !important;'><strong>"+response.message+" </strong></p></div>");
                          $('#displayDiv').show();
                          $('#title').val("");
                          $('#duration').val("");
                          $('#description').val("");
                      }
                      alert(response.message);
                      $("#addCourseModal").modal('hide');
                      window.location.reload();
                  }
              });
          }
      }
  }
  function getCourseDetails(id,postUrl) {

        $.ajax({
            type: 'POST',
            url: postUrl,
            data: { id: id },
            dataType: 'JSON',
            success: function(response) {
                if (response.flag == 0) {
                    $("#displayDiv").empty();
                    $("#displayDiv").prepend("<div class='alert alert-danger alert-dismissable fade show' id='alertDiv'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button><p style='margin-bottom: 0rem !important;'><strong>"+response.message+" </strong></p></div>");
                    $('#displayDiv').show();
                } else {
                    $("#displayDiv").empty();
                    $("#displayDiv").prepend("<div class='alert alert-success alert-dismissable fade show' id='alertDiv'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button><p style='margin-bottom: 0rem !important;'><strong>"+response.message+" </strong></p></div>");
                    $('#displayDiv').show();
                    $('#editTitle').val("");
                    $('#editDuration').val("");
                    $('#editDescription').val("");
                }
                $('#courseTitle').val(response[0].courseDescription);
                $('#courseDuration').val(response[0].courseDuration);
                $('#courseDescription').val(response[0].courseTitle);
                if(response[0].title != null ){
                  for (var i = 0; i < response.length; i++) {
                    var htmlData = '<div class="form-row"><div class="col-md-4 mb-3"><label for="courseTitle">Topic Title</label><input type="text" class="form-control" value='+response[i].title+' readonly></div><div class="col-md-4 mb-3"><label for="courseDescription">Description</label><input type="text" class="form-control" value='+response[i].description+' readonly></div></div>';
                    $('#newForm').append(htmlData);
                  }
                }
                else {
                  var htmlData = '<div class="form-row">Topics not added for this course</div>';
                  $('#newForm').append(htmlData);
                }
            }
        });
  }

  function deleteTopic(id,postUrl){

    if (confirm("Are you sure you want to delete this Topic?") == true) {
      $.ajax({
          type: 'POST',
          url: postUrl,
          data: { id: id },
          dataType: 'JSON',
          success: function(response) {
              alert(response.message);
              window.location.reload();
          }
      });
    }
  }

  function deleteCourse(id,postUrl){
    if (confirm("Are you sure you want to delete this Course?") == true) {
      $.ajax({
          type: 'POST',
          url: postUrl,
          data: { id: id },
          dataType: 'JSON',
          success: function(response) {
              alert(response.message);
              window.location.reload();
          }
      });
    }
  }

  function getTopicDetailsById(id,postUrl){
      $('#editId').val(id);
      $.ajax({
          type: 'POST',
          url: postUrl,
          data: { id: id },
          dataType: 'JSON',
          success: function(response) {
                $('#editTitle').val(response.title);
                $('#editCourse').val(response.course_id);
                $('#editDescription').val(response.description);
          }
      });
  }

  function getCourseDetailsById(id,postUrl){
      $('#editId').val(id);
      $.ajax({
          type: 'POST',
          url: postUrl,
          data: { id: id },
          dataType: 'JSON',
          success: function(response) {
                $('#editTitle').val(response.title);
                $('#editDuration').val(response.duration);
                $('#editDescription').val(response.description);
          }
      });
  }
