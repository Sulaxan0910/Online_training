<?php

namespace App\Models;

use CodeIgniter\Model;

class CourseModel extends Model
{
    protected $table        = 'course';
    protected $primaryKey   = 'id';
    protected $useAutoIncrement = true;

    protected $useSoftDeletes = true;

    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';
    protected $allowedFields = [ 'title','description','duration'];

    public function getCourseDetails($id='')
    {
        $db = \Config\Database::connect();
        $query = $db->query('SELECT t.title,t.description,c.duration as courseDuration,c.title as courseTitle,c.description as courseDescription FROM `topic` t RIGHT JOIN course c ON c.id=t.course_id WHERE t.deleted_at IS NULL AND c.deleted_at IS NULL AND c.id="'.$id.'" GROUP BY t.id ');
        return $query->getResultArray();
    }

    public function getCourseDetailsById($id='')
    {
        $db = \Config\Database::connect();
        $query = $db->query('SELECT * FROM course WHERE deleted_at IS NULL AND id="'.$id.'" ');
        return $query->getRowArray();
    }
}
