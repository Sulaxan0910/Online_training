<?php

namespace App\Models;

use CodeIgniter\Model;

class TopicModel extends Model
{
    protected $table        = 'topic';
    protected $primaryKey   = 'id';
    protected $useAutoIncrement = true;

    protected $useSoftDeletes = true;

    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';
    protected $allowedFields = [ 'title','description','course_id'];

    public function getAllTopics(){
      $db = \Config\Database::connect();
      $query = $db->query('SELECT t.id,t.title,t.description,c.title as course FROM `topic` t INNER JOIN course c ON c.id=t.course_id WHERE t.deleted_at IS NULL AND c.deleted_at IS NULL ');
      return $query->getResultArray();
    }

    public function getTopicDetailsById($id='')
    {
        $db = \Config\Database::connect();
        $query = $db->query('SELECT * FROM topic WHERE deleted_at IS NULL AND id="'.$id.'" ');
        return $query->getRowArray();
    }
}
