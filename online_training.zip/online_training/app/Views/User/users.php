
<div class="row">
   <div class="col-sm-12 col-md-2 col-lg-2" style="margin:5px 0px">
      <!-- Button trigger modal -->
      <button type="button" class="btn btn-primary btn-sm" style="width: 100%;" data-toggle="modal" data-target="#addUserModal">
      Add User
      </button>
  </div>
</div>
<div class="table-responsive">
   <table class="table table-bordered table-hover" id="usersTable" style="width:100% !important;">
      <thead class="table-primary">
         <tr>
            <th>#</th>
            <th>Full Name</th>
            <th>Username</th>
            <th>Email</th>
            <th>User Type</th>
            <th>Department</th>
            <th>Status</th>
            <th>Action</th>
         </tr>
      </thead>
      <tbody>
      </tbody>
   </table>
</div>

<!-- Add User Modal -->
<div class="modal fade" id="addUserModal" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="addUserModalTitle" aria-hidden="true">
   <div class="modal-dialog modal-dialog-centered modal-xl" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="addUserModalTitle">Add User</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
         </div>
         <div class="modal-body">
            <div class="col-md-12">
               <form class="needs-validation" id="newForm" novalidate  onsubmit="event.preventDefault();">
                  <div class="form-row">
                     <div class="col-md-4 mb-3">
                        <label for="username">Username</label>
                        <input type="text" class="form-control" id="username" placeholder="Username" required>
                        <div class="invalid-feedback">
                           Please Enter User Name.
                        </div>
                     </div>
                     <div class="col-md-4 mb-3">
                        <label for="fullName">Full Name</label>
                        <input type="text" class="form-control" id="fullName" placeholder="Full Name" required>
                        <div class="invalid-feedback">
                           Please Enter Full Name.
                        </div>
                     </div>
                     <div class="col-md-4 mb-3">
                        <label for="email">Email</label>
                        <div class="input-group">
                           <!--
                              <div class="input-group-prepend">
                                 <span class="input-group-text" id="inputGroupPrepend">@</span> aria-describedby="inputGroupPrepend"
                              </div> -->
                           <input type="email" class="form-control" id="email" placeholder="example@example.com"required>
                           <div class="invalid-feedback">
                              Please Enter a valid Email.
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="form-row">
                     <div class="col-md-4 mb-3">
                        <label for="password">Password</label>
                        <input type="password" class="form-control" id="password" placeholder="Password" required>
                        <div class="invalid-feedback">
                           Please Enter Password.
                        </div>
                     </div>
                  </div>
                  <div class="modal-footer">
		              <button class="btn btn-primary" id="savenew" onclick="saveUser(0,'<?php echo base_url('User/saveUser'); ?>')" >Save</button>
		              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
	          	  </div>
               </form>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- Edit User Modal -->
                        <div class='modal fade' id='editUserModal' data-backdrop="static" tabindex='-1' role='dialog' aria-labelledby='editUserModalTitle' aria-hidden='true'>
                           <div class='modal-dialog modal-dialog-centered modal-xl' role='document'>
                              <div class='modal-content'>
                                 <div class='modal-header'>
                                    <h5 class='modal-title' id='editUserModalTitle'>Edit User</h5>
                                    <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
                                    <span aria-hidden='true'>&times;</span>
                                    </button>
                                 </div>
                                 <div class='modal-body'>
                                    <div class='col-md-12'>
                                       <form class='needs-validation' id='editForm' novalidate onsubmit='event.preventDefault();'>
                                          <input type="hidden" id="editId" value="0">
                                          <div class='form-row'>
                                             <div class='col-md-4 mb-3'>
                                                <label for='editUsername'>Username</label>
                                                <input type='text' class='form-control' id='editUsername' placeholder='Username' value="" required>
                                                <div class='invalid-feedback'>
                                                   Please Enter User Name.
                                                </div>
                                             </div>
                                             <div class='col-md-4 mb-3'>
                                                <label for='editFullName'>Full Name</label>
                                                <input type='text' class='form-control' id='editFullName' placeholder='Full Name' value="" required>
                                                <div class='invalid-feedback'>
                                                   Please Enter Full Name.
                                                </div>
                                             </div>
                                             <div class='col-md-4 mb-3'>
                                                <label for='editEmail'>Email</label>
                                                <div class='input-group'>
                                                   <input type='email' class='form-control' id='editEmail' value=""  placeholder='example@example.com'required>
                                                   <div class='invalid-feedback'>
                                                      Please Enter a valid Email.
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <div class='form-row'>
                                             <div class='col-md-4 mb-3'>
                                                <label for='editPassword'>Password</label>
                                                <input type='password' class='form-control' id='editPassword' placeholder='Password'>
                                             </div>
                                          </div>
                                      <div class='modal-footer'>
                                             <button class='btn btn-primary' id='editSave' onClick='saveUser(1,"<?php echo base_url('User/saveUser'); ?>")'>Save</button>
                                            <button type='button' id='editClose' onclick="emptydropdowns('user')" class='btn btn-secondary' data-dismiss='modal'>Close</button>
                                         </div>
                                       </form>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
