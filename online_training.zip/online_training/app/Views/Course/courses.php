
<div class="row">
   <div class="col-sm-12 col-md-2 col-lg-2" style="margin:5px 0px">
      <!-- Button trigger modal -->
      <button type="button" class="btn btn-primary btn-sm" style="width: 100%;" data-toggle="modal" data-target="#addCourseModal">
      Add Courses
      </button>
  </div>
</div>
<div class="table-responsive">
   <table class="table table-bordered table-hover" id="usersTable" style="width:100% !important;">
      <thead class="table-primary">
         <tr>
            <th>#</th>
            <th>Title</th>
            <th>Description</th>
            <th>Duration</th>
            <th>Action</th>
         </tr>
      </thead>
      <tbody>

          <?php
          if(empty($courses)){
            ?>
            <tr><td colspan="5" style="text-align: center;">No Data Available</td></tr>
            <?php
          }else{
            $c=0;
            foreach ($courses as $key => $value) {
              ?>
              <tr>
                <td><?php echo ++$c; ?></td>
                <td><?php echo $value['title']; ?></td>
                <td><?php echo $value['description']; ?></td>
                <td><?php echo $value['duration'].' days'; ?></td>
                <td>

                  <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#editCourseModal" title="Edit Course" onclick="getCourseDetailsById(<?php echo $value['id']; ?>,'<?php echo base_url('Course/getCourseDetailsById') ?>')">
                  Edit Course
                  </button>
                  <button class="btn btn-danger btn-sm" type="button" onclick="deleteCourse(<?php echo $value['id']; ?>,'<?php echo base_url('Course/deleteCourse') ?>')" title="Delete Course">Delete</button> </td>
              </tr>
              <?php
            }
          }
          ?>
      </tbody>
   </table>
</div>

<!-- Add Course Modal -->
<div class="modal fade" id="addCourseModal" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="addCourseModalTitle" aria-hidden="true">
   <div class="modal-dialog modal-dialog-centered modal-xl" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="addCourserModalTitle">Add Course</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
         </div>
         <div class="modal-body">
            <div class="col-md-12">
               <form class="needs-validation" id="newForm" novalidate  onsubmit="event.preventDefault();">
                  <div class="form-row">
                     <div class="col-md-4 mb-3">
                        <label for="title">Title</label>
                        <input type="text" class="form-control" id="title" placeholder="Title" required>
                        <div class="invalid-feedback">
                           Please Enter Title.
                        </div>
                     </div>
                     <div class="col-md-4 mb-3">
                        <label for="description">Description</label>
                        <input type="text" class="form-control" id="description" placeholder="Description" required>
                        <div class="invalid-feedback">
                           Please Enter Description.
                        </div>
                     </div>
                     <div class="col-md-4 mb-3">
                        <label for="duration">Duration</label>
                        <div class="input-group">
                           <input type="number" class="form-control" id="duration" placeholder="Duration(in Days)"required>
                           <div class="invalid-feedback">
                              Please Enter Duration.
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="modal-footer">
		              <button class="btn btn-primary" id="savenew" onclick="saveCourse(0,'<?php echo base_url('Course/saveCourse'); ?>')" >Save</button>
		              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
	          	  </div>
               </form>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- Edit Course Modal -->
                        <div class='modal fade' id='editCourseModal' data-backdrop="static" tabindex='-1' role='dialog' aria-labelledby='editCourserModalTitle' aria-hidden='true'>
                           <div class='modal-dialog modal-dialog-centered modal-xl' role='document'>
                              <div class='modal-content'>
                                 <div class='modal-header'>
                                    <h5 class='modal-title' id='editCourseModalTitle'>Edit Course</h5>
                                    <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
                                    <span aria-hidden='true'>&times;</span>
                                    </button>
                                 </div>
                                 <div class='modal-body'>
                                    <div class='col-md-12'>
                                       <form class='needs-validation' id='editForm' novalidate onsubmit='event.preventDefault();'>
                                          <input type="hidden" id="editId" value="0">
                                          <div class='form-row'>
                                             <div class='col-md-4 mb-3'>
                                                <label for='editTitle'>Title</label>
                                                <input type='text' class='form-control' id='editTitle' value="" required>
                                                <div class='invalid-feedback'>
                                                   Please Enter Title.
                                                </div>
                                             </div>
                                             <div class='col-md-4 mb-3'>
                                                <label for='editDescription'>Description</label>
                                                <input type='text' class='form-control' id='editDescription' value="">
                                                <div class='invalid-feedback'>
                                                   Please Enter Description.
                                                </div>
                                             </div>
                                             <div class='col-md-4 mb-3'>
                                                <label for="editDuration">Duration</label>
                                                <div class="input-group">
                                                   <input type="number" class="form-control" id="editDuration" required>
                                                   <div class="invalid-feedback">
                                                      Please Enter Duration.
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                       </form>
                                    </div>
                                 </div>
                                 <div class='modal-footer'>
                                    <button class='btn btn-primary' id='editSave' onClick='saveCourse(1,"<?php echo base_url('Course/saveCourse'); ?>")'>Save</button>
                                   <button type='button' id='editClose' class='btn btn-secondary' data-dismiss='modal'>Close</button>
                                   <input type="hidden" id="editId" value="">
                                </div>
                              </div>
                           </div>
                        </div>
