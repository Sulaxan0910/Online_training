
<div class="table-responsive">
   <table class="table table-bordered table-hover" id="usersTable" style="width:100% !important;">
      <thead class="table-primary">
         <tr>
            <th>#</th>
            <th>Title</th>
            <th>Description</th>
            <th>Duration</th>
            <th>Action</th>
         </tr>
      </thead>
      <tbody>

          <?php
          if(empty($courses)){
            ?>
            <tr><td colspan="5" style="text-align: center;">No Data Available</td></tr>
            <?php
          }else{
            $c=0;
            foreach ($courses as $key => $value) {
              ?>
              <tr>
                <td><?php echo ++$c; ?></td>
                <td><?php echo $value['title']; ?></td>
                <td><?php echo $value['description']; ?></td>
                <td><?php echo $value['duration']; ?></td>
                <td> <button class="btn btn-success" type="button" data-toggle="modal" data-target="#CourseDetailsModal" onclick="getCourseDetails(<?php echo $value['id']; ?>,'<?php echo base_url('Course/getCourseDetails'); ?>')">View Details</button> </td>
              </tr>
              <?php
            }
          }
          ?>
      </tbody>
   </table>
</div>

<!-- Add Enroll Course Modal -->
<div class="modal fade" id="CourseDetailsModal" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="CourseDetailsModalTitle" aria-hidden="true">
   <div class="modal-dialog modal-dialog-centered modal-xl" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="CourseDetailsModalTitle">Course Details</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
         </div>
         <div class="modal-body">
            <div class="col-md-12">
               <form class="needs-validation" id="newForm" novalidate  onsubmit="event.preventDefault();">
                  <div class="form-row">
                     <div class="col-md-4 mb-3">
                        <label for="courseTitle">Course Title</label>
                        <input type="text" class="form-control" id="courseTitle" readonly>
                     </div>
                     <div class="col-md-4 mb-3">
                        <label for="courseDescription">Description</label>
                        <input type="text" class="form-control" id="courseDescription" readonly>
                     </div>
                     <div class="col-md-4 mb-3">
                        <label for="courseDuration">Duration</label>
                        <div class="input-group">
                           <input type="number" class="form-control" id="courseDuration" readonly>
                        </div>
                     </div>
                  </div>
               </form>
            </div>
         </div>
         <div class="modal-footer">
         <button class="btn btn-primary" id="savenew" onclick="enrollCourse(0,'<?php echo base_url('Course/enrollCourse'); ?>')" >Enroll Course</button>
         <button type="button" class="btn btn-secondary" data-dismiss="modal" onclick="window.location.reload()">Close</button>
       </div>
      </div>
   </div>
</div>
