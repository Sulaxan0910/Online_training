<?php echo view('includes/header');?>

<?php echo view('includes/top_navigation');?>

<?php echo view('includes/side_bar');?>

<?php echo view($main_content); ?>

<?php echo view('includes/footer');?>
