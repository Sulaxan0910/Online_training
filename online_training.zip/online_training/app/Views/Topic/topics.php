
<div class="row">
   <div class="col-sm-12 col-md-2 col-lg-2" style="margin:5px 0px">
      <!-- Button trigger modal -->
      <button type="button" class="btn btn-primary btn-sm" style="width: 100%;" data-toggle="modal" data-target="#addTopicModal">
      Add Topic
      </button>
  </div>
</div>
<div class="table-responsive">
   <table class="table table-bordered table-hover" id="usersTable" style="width:100% !important;">
      <thead class="table-primary">
         <tr>
            <th>#</th>
            <th>Title</th>
            <th>Description</th>
            <th>Course</th>
            <th>Action</th>
         </tr>
      </thead>
      <tbody>
        <?php
        if(empty($topics)){
          ?>
          <tr><td colspan="5" style="text-align: center;">No Data Available</td></tr>
          <?php
        }else{
          $c=0;
          foreach ($topics as $key => $value) {
            ?>
            <tr>
              <td><?php echo ++$c; ?></td>
              <td><?php echo $value['title']; ?></td>
              <td><?php echo $value['description']; ?></td>
              <td><?php echo $value['course']; ?></td>
              <td>

                <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#editTopicModal" title="Edit Topic" onclick="getTopicDetailsById(<?php echo $value['id']; ?>,'<?php echo base_url('Topic/getTopicDetailsById') ?>')">
                Edit Topic
                </button>
                <button class="btn btn-danger btn-sm" type="button" onclick="deleteTopic(<?php echo $value['id']; ?>,'<?php echo base_url('Topic/deleteTopic') ?>')" title="Delete Topic">Delete</button> </td>
            </tr>
            <?php
          }
        }
        ?>
      </tbody>
   </table>
</div>

<!-- Add Topic Modal -->
<div class="modal fade" id="addTopicModal" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="addTopicModalTitle" aria-hidden="true">
   <div class="modal-dialog modal-dialog-centered modal-xl" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="addTopicModalTitle">Add Topic</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
         </div>
         <div class="modal-body">
            <div class="col-md-12">
               <form class="needs-validation" id="newForm" novalidate  onsubmit="event.preventDefault();">
                  <div class="form-row">
                     <div class="col-md-4 mb-3">
                        <label for="title">Title</label>
                        <input type="text" class="form-control" id="title" placeholder="Title" required>
                        <div class="invalid-feedback">
                           Please Enter Title.
                        </div>
                     </div>
                     <div class="col-md-4 mb-3">
                        <label for="description">Description</label>
                        <input type="text" class="form-control" id="description" placeholder="Description" required>
                        <div class="invalid-feedback">
                           Please Enter Description.
                        </div>
                     </div>
                     <div class="col-md-4 mb-3">
                        <label for="course">Course</label>
                        <select class="form-control" id="course" required>
                           <option value="">Select Course</option>
                           <?php
                           foreach ($courses as $key => $value) {
                              ?>
                              <option value='<?php echo $value['id'] ?>'><?php echo $value['title']?></option>
                              <?php
                           }
                           ?>
                        </select>
                        <div class="invalid-feedback">
                           Please Select Course.
                        </div>
                     </div>
                  </div>
                  <div class="modal-footer">
		              <button class="btn btn-primary" id="savenew" onclick="saveTopic(0,'<?php echo base_url('Topic/saveTopic'); ?>')" >Save</button>
		              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
	          	  </div>
               </form>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- Edit Topic Modal -->
                        <div class='modal fade' id='editTopicModal' data-backdrop="static" tabindex='-1' role='dialog' aria-labelledby='editTopicModalTitle' aria-hidden='true'>
                           <div class='modal-dialog modal-dialog-centered modal-xl' role='document'>
                              <div class='modal-content'>
                                 <div class='modal-header'>
                                    <h5 class='modal-title' id='editTopicModalTitle'>Edit Topic</h5>
                                    <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
                                    <span aria-hidden='true'>&times;</span>
                                    </button>
                                 </div>
                                 <div class='modal-body'>
                                    <div class='col-md-12'>
                                       <form class='needs-validation' id='editForm' novalidate onsubmit='event.preventDefault();'>
                                          <input type="hidden" id="editId" value="0">
                                          <div class='form-row'>
                                             <div class='col-md-4 mb-3'>
                                                <label for='editTitle'>Title</label>
                                                <input type='text' class='form-control' id='editTitle' value="" required>
                                                <div class='invalid-feedback'>
                                                   Please Enter User Name.
                                                </div>
                                             </div>
                                             <div class='col-md-4 mb-3'>
                                                <label for='editDescription'>Description</label>
                                                <input type='text' class='form-control' id='editDescription' value="" >
                                                <div class='invalid-feedback'>
                                                   Please Enter Full Name.
                                                </div>
                                             </div>
                                             <div class='col-md-4 mb-3'>
                                                <label for="editCourse">Course</label>
                                                <select class="form-control" id="editCourse" required>
                                                   <option value="">Select Course</option>
                                                   <?php
                                                   foreach ($courses as $key => $value) {
                                                      ?>
                                                      <option value='<?php echo $value['id'] ?>'><?php echo $value['title']?></option>
                                                      <?php
                                                   }
                                                   ?>
                                                </select>
                                             </div>
                                          </div>
                                       </form>
                                    </div>
                                 </div>
                                 <div class='modal-footer'>
                                    <button class='btn btn-primary' id='editSave' onClick='saveTopic(1,"<?php echo base_url('Topic/saveTopic'); ?>")'>Save</button>
                                   <button type='button' id='editClose' class='btn btn-secondary' data-dismiss='modal'>Close</button>
                                   <input type="hidden" id="editId" value="">
                                </div>
                              </div>
                           </div>
                        </div>
