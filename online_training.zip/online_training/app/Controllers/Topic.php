<?php

namespace App\Controllers;

use App\Models\CourseModel;
use App\Models\TopicModel;

class Topic extends BaseController
{
    protected $courseModel;
    protected $topicModel;
    public function __construct()
    {
      $db = \Config\Database::connect();
      $this->courseModel = new CourseModel();
      $this->topicModel = new TopicModel();
    }
    public function index()
    {
        return view('welcome_message');
    }
    public function topics()
    {
        $data['courses']=$this->courseModel->where(array('deleted_at' => NULL))->findAll();
        $data['topics']=$this->topicModel->getAllTopics();
		    $data['breadcrumb']='Topics';
		    $data['main_content']='Topic/topics';
        return view('includes/templates',$data);
    }

  	public function saveTopic()
  	{
  		$data = array();
  		$this->request->getVar('id') != null  ? $id = $this->request->getVar('id') : "";
  		$this->request->getVar('title') != null ? $data['title'] = $this->request->getVar('title') : "";
  		$this->request->getVar('description') != null  ? $data['description'] = $this->request->getVar('description') : "";
  		$this->request->getVar('course') != null  ? $data['course_id'] = $this->request->getVar('course') : "";
  		if(!isset($id))		//insert data
  		{
  			$this->topicModel->insert($data);
  			$returnData['message'] = "Topic Inserted Successfully";
  			$returnData['flag'] = 1;
  			$returnData['redirectUrl'] = base_url('topics');
  		}
  		else				//update data
  		{
  			$this->topicModel->update($id, $data);
  			$returnData['message'] = "Topic Updated Successfully";
  			$returnData['flag'] = 1;
  			$returnData['redirectUrl'] = base_url('topics');
  		}
  		echo json_encode($returnData);
  	}

  	public function deleteTopic()
  	{
  		$this->request->getVar('id') != null  ? $id = $this->request->getVar('id') : "";
  		if(isset($id))
  		{
  			$this->topicModel->delete($id);
  			$returnData['message'] = "Topic Deleted Successfully";
  			$returnData['flag'] = 1;
  			$returnData['redirectUrl'] = base_url('topics');
  		}
  		else
  		{
  			$returnData['message'] = "Delete Topic Un-Successfull";
  			$returnData['flag'] = 0;
  			$returnData['redirectUrl'] = base_url('topics');
  		}
  		echo json_encode($returnData);
  	}

    public function getTopicDetailsById()
    {
        $this->request->getVar('id') != null  ? $id = $this->request->getVar('id') : "";
        echo json_encode($this->topicModel->getTopicDetailsById($id));
    }
}
