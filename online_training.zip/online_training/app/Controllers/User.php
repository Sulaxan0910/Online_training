<?php

namespace App\Controllers;

class User extends BaseController
{
    public function index()
    {
        return view('welcome_message');
    }
    public function users()
    {
		    $data['breadcrumb']='Users';
		    $data['main_content']='User/users';
        return view('includes/templates',$data);
    }
}
