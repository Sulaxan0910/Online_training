<?php
namespace App\Controllers;

use App\Models\LoginModel;

class Login extends BaseController
{
    public function index()
    {
        $userSession = $this->session->get();
        // print_r($userSession);exit;
        if(isset($userSession['logged_in']) && $userSession['logged_in'] == true)
            return redirect()->route('home');
        else
            return view('Login');
    }
    
    public function ValidateUser()
    {
        $db = \Config\Database::connect();
        $model = new LoginModel();
        $username = $this->request->getVar('username');
        $password = $this->request->getVar('password');
        $userQuery = $model->where(array('username' => $username, 'password' => md5($password)));
        if($userQuery->countAllResults()==0)
            $data['flag'] = 0;
        else{
            $userData = $model->where(array('username' => $username, 'password' => md5($password)))->first();
            $sessionUserData = [
                    'id'                =>  $userData['id'],
                    'username'          =>  $userData['username'],
                    'userEmail'         =>  $userData['email'],
                    'fullName'          =>  $userData['fullName'],  
                    'userType'          =>  $userData['userType'],
                    'userStatus'        =>  $userData['userStatus'],
                    'logged_in'         =>  TRUE
            ];
            $this->session->set($sessionUserData);
            $data['flag'] = 1;
            $data['redirectUrl'] = base_url('home');
        }
        echo json_encode($data);
    }
    
    public function logout()
    {
        $this->session->destroy();
        return redirect()->route('/');
    }
}
