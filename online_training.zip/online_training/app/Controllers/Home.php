<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
		    $data['breadcrumb']='Dashboard';
		    $data['main_content']='dashboard';
        return view('includes/templates',$data);
    }
}
