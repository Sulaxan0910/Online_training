<?php

namespace App\Controllers;

use App\Models\CourseModel;

class Course extends BaseController
{
    protected $courseModel;
    public function __construct()
    {
      $db = \Config\Database::connect();
      $this->courseModel = new CourseModel();
    }
    public function index()
    {
        return view('welcome_message');
    }
    public function courses()
    {
        $data['courses']=$this->courseModel->where(array('deleted_at' => NULL))->findAll();
		    $data['breadcrumb']='Courses';
		    $data['main_content']='Course/Courses';
        return view('includes/templates',$data);
    }
    public function enrollCourses()
    {
        $data['courses']=$this->courseModel->where(array('deleted_at' => NULL))->findAll();
		    $data['breadcrumb']=' Enroll Courses';
		    $data['main_content']='Course/enrollCourses';
        return view('includes/templates',$data);
    }
    public function getCourseDetails()
    {
        $this->request->getVar('id') != null  ? $id = $this->request->getVar('id') : "";
        echo json_encode($this->courseModel->getCourseDetails($id));
    }

  	public function saveCourse()
  	{
  		$data = array();
  		$this->request->getVar('id') != null  ? $id = $this->request->getVar('id') : "";
  		$this->request->getVar('title') != null ? $data['title'] = $this->request->getVar('title') : "";
  		$this->request->getVar('description') != null  ? $data['description'] = $this->request->getVar('description') : "";
  		$this->request->getVar('duration') != null  ? $data['duration'] = $this->request->getVar('duration') : "";
  		if(!isset($id))		//insert data
  		{
  			$this->courseModel->insert($data);
  			$returnData['message'] = "Course Inserted Successfully";
  			$returnData['flag'] = 1;
  			$returnData['redirectUrl'] = base_url('courses');
  		}
  		else				//update data
  		{
  			$this->courseModel->update($id, $data);
  			$returnData['message'] = "Course Updated Successfully";
  			$returnData['flag'] = 1;
  			$returnData['redirectUrl'] = base_url('courses');
  		}
  		echo json_encode($returnData);
  	}

  	public function deleteCourse()
  	{
  		$this->request->getVar('id') != null  ? $id = $this->request->getVar('id') : "";
  		if(isset($id))
  		{
  			$this->courseModel->delete($id);
  			$returnData['message'] = "Course Deleted Successfully";
  			$returnData['flag'] = 1;
  			$returnData['redirectUrl'] = base_url('courses');
  		}
  		else
  		{
  			$returnData['message'] = "Delete Course Un-Successfull";
  			$returnData['flag'] = 0;
  			$returnData['redirectUrl'] = base_url('courses');
  		}
  		echo json_encode($returnData);
  	}
    
    public function getCourseDetailsById()
    {
        $this->request->getVar('id') != null  ? $id = $this->request->getVar('id') : "";
        echo json_encode($this->courseModel->getCourseDetailsById($id));
    }
}
