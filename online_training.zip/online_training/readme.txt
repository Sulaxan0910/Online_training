As given in the problem statement I have implemented the online Training web portal
I had wished to do the user module(logins and authentications) but couldn't due to time constraints

I have used CodeIgniter 4 framework to implement this web portal
I have used templating so that I can reuse the Code
I have used Bootstrap 5 template which is the latest version of Bootstrap from https://startbootstrap.com/template/sb-admin

I have two masters, Course master and the topic master
Topics are assigned to courses accordingly
one course can have multiple topics, but one topic is only assigned to one courses

As per the problem statement given I have done CRUD operations on Topics and Courses

Also I wished to enroll course to user but user module was incomplete so couldn't
